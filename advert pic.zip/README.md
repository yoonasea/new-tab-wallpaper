# new-tab-wallpaper
Chrome extension: new tab will show random wallpaper
description